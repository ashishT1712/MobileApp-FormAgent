package com.example.mirajimlilingwa.formagent;

import android.support.v7.app.AppCompatActivity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by charlie on 11/19/17.
 */

public class validateUser extends AppCompatActivity{
    private Pattern pattern1;
    private Matcher matchString;

    private static final String userValidate = "^[a-z0-9_-]{6,15}$";


    public validateUser(){
        pattern1 = Pattern.compile(userValidate);
    }
    public boolean validate(final String user){
        matchString = pattern1.matcher(user);
        return matchString.matches();
    }
}