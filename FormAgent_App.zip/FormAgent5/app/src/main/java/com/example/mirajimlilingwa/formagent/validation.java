package com.example.mirajimlilingwa.formagent;

import android.support.v7.app.AppCompatActivity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by charlie on 11/19/17.
 */

public class validation extends AppCompatActivity{
    private Pattern pattern;
    private Matcher matchString;

    private static final String passwordValidate = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";


    public validation(){
        pattern = Pattern.compile(passwordValidate);
    }
    public boolean validate(final String pass){
        matchString = pattern.matcher(pass);
        return matchString.matches();
    }
}
