package com.example.mirajimlilingwa.formagent;

import android.provider.BaseColumns;

/**
 * Created by mstch on 11/3/2017.
 */

public final class DatabaseContract {


    private DatabaseContract() {}

    public static class TableLayout implements BaseColumns
    {
        public static final String Table_Name = "entry";
        public static final String Column_Name_Title = "title";
        public static final String Column_Name_Subtitle = "subtitle";
    }
}
