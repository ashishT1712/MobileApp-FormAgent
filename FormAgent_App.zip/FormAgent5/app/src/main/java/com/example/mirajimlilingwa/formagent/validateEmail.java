package com.example.mirajimlilingwa.formagent;

import android.support.v7.app.AppCompatActivity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by charlie on 11/19/17.
 */

public class validateEmail extends AppCompatActivity {
        private Pattern pattern2;
        private Matcher matchString;

        private static final String emailValidate = "^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$";


        public validateEmail(){
            pattern2 = Pattern.compile(emailValidate);
        }
        public boolean validate(final String pass){
            matchString = pattern2.matcher(pass);
            return matchString.matches();
        }
    }


