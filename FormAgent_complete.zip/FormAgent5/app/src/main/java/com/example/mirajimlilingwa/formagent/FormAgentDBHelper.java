package com.example.mirajimlilingwa.formagent;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.TableLayout;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by mstch on 11/3/2017.
 */

public final class FormAgentDBHelper extends SQLiteOpenHelper {

    //If you change db schema, you must increment database version
    private static final int Database_Version = 1;
    //database name
    private static final String Database_Name = "FormAgent";
    //contacts table name Admin
    private static final String TABLE_ADMIN_DETAIL = "AdminDetails";

    private static final String TABLE_USER_DETAIL = "UserDetails";
    //contact table column names
    private static final String KEY_ID = "id";
    private static final String KEY_LastName = "LastName";
    private static final String KEY_FirstName = "FirstName";
    private static final String KEY_Username = "Username";
    private static final String KEY_Password = "password";
    private static final String KEY_email = "email";
    private static final String KEY_CompanyName = "CompanyName";
    private static final String KEY_CompanyKey = "CompanyKey";

    String CREATE_ADMIN_DETAIL_TABLE = "CREATE TABLE " + TABLE_ADMIN_DETAIL + "("
            + KEY_ID + " INTEGER PRIMARY KEY,"
            + KEY_LastName + " TEXT,"
            + KEY_FirstName + " TEXT,"
            + KEY_Username + " TEXT,"
            + KEY_Password + " TEXT,"
            + KEY_email + " TEXT,"
            + KEY_CompanyName + " TEXT,"
            + KEY_CompanyKey + " TEXT " + ")";
    String CREATE_USER_DETAIL_TABLE = "CREATE TABLE " + TABLE_USER_DETAIL + "("
            + KEY_ID + " INTEGER PRIMARY KEY,"
            + KEY_LastName + " TEXT,"
            + KEY_FirstName + " TEXT,"
            + KEY_Username + " TEXT,"
            + KEY_Password + " TEXT,"
            + KEY_email + " TEXT " + ")";

    public FormAgentDBHelper(Context context) {
        super(context, Database_Name, null, Database_Version);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL(CREATE_USER_DETAIL_TABLE);
        db.execSQL(CREATE_ADMIN_DETAIL_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        //drop older table if existed
        db.execSQL("DROP TABLE IF EXITS " + TABLE_ADMIN_DETAIL);
        db.execSQL("DROP TABLE IF EXITS " + TABLE_USER_DETAIL);
        //create again
        onCreate(db);
    }

    public void addNewUser(UserObject user)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(KEY_FirstName, user.getFirst_Name());
        values.put(KEY_LastName, user.getLast_Name());
        values.put(KEY_Username, user.getUsername());
        values.put(KEY_email, user.geteMail());
        values.put(KEY_Password, user.getPassword());
        //insert Row
        db.insert(TABLE_USER_DETAIL, null, values);
        db.close();
    }
    public List<UserObject> getAllUserList()
    {
        List<UserObject> UserList = new ArrayList<UserObject>();
        String selectQuery = "SELECT * FROM " + TABLE_USER_DETAIL;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        //looping through all rows and adding to list
        if (cursor.moveToFirst())
        {
            do {

                //ID,Last,First,Username,PW, Email, Company,Key
                UserObject user = new UserObject();
                user.setId(Integer.parseInt(cursor.getString(0)));
                user.setLast_Name(cursor.getString(1));
                user.setFirst_Name(cursor.getString(2));
                user.setUsername(cursor.getString(3));
                user.setPassword(cursor.getString(4));
                user.seteMail(cursor.getString(5));
                //add to list
                UserList.add(user);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        //return admin list
        return UserList;

    }
    public void addNewAdmin(AdminObject admin)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(KEY_FirstName, admin.getFirst_Name());
        values.put(KEY_LastName, admin.getLast_Name());
        values.put(KEY_Username, admin.getUsername());
        values.put(KEY_email, admin.geteMail());
        values.put(KEY_Password, admin.getPassword());
        //insert Row
        db.insert(TABLE_ADMIN_DETAIL, null, values);
        db.close(); //closing db connection
    }
    public List<AdminObject> getAllAdminList()
    {
        List<AdminObject> adminList = new ArrayList<AdminObject>();

        //Select All Query
        String selectQuery = "SELECT * FROM " + TABLE_ADMIN_DETAIL;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        //looping through all rows and adding to list
        if (cursor.moveToFirst())
        {
            do {

                //ID,Last,First,Username,PW, Email, Company,Key
                AdminObject admin = new AdminObject();
                admin.setId(Integer.parseInt(cursor.getString(0)));
                admin.setLast_Name(cursor.getString(1));
                admin.setFirst_Name(cursor.getString(2));
                admin.setUsername(cursor.getString(3));
                admin.setPassword(cursor.getString(4));
                admin.seteMail(cursor.getString(5));
                admin.setCompany_Name(cursor.getString(6));
                admin.setCompany_Key(cursor.getString(7));

                //add to list
                adminList.add(admin);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        //return admin list
        return adminList;
    }

    public AdminObject getAdmin(String Lastname, String FirstName)
    {
        List<AdminObject> adminList = new ArrayList<AdminObject>();

        //Select All Query
        String selectQuery = "SELECT * FROM " + TABLE_ADMIN_DETAIL;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        //looping through all rows and adding to list
        if (cursor.moveToFirst())
        {
            do {

                //ID,Last,First,Email,Username,PW,Company,Key
                AdminObject admin = new AdminObject();
                admin.setId(Integer.parseInt(cursor.getString(0)));
                admin.setLast_Name(cursor.getString(1));
                admin.setFirst_Name(cursor.getString(2));
                admin.seteMail(cursor.getString(3));
                admin.setUsername(cursor.getString(4));
                admin.setPassword(cursor.getString(5));
                admin.setCompany_Name(cursor.getString(6));
                admin.setCompany_Key(cursor.getString(7));

                //add to list
                adminList.add(admin);
            } while (cursor.moveToNext());
        }
        for (AdminObject adm : adminList)
        {
            String fname = adm.getLast_Name();
            String lname = adm.getLast_Name();
            if(fname.equals(FirstName) && lname.equals(Lastname))
                //if found
                return adm;
        }
        //if not found
        return null;
    }
    public boolean UpdateAdminCompany(String Lastname, String CompanyName, String Companykey)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(KEY_CompanyName, CompanyName);
        cv.put(KEY_CompanyKey, Companykey);
        db.update(TABLE_ADMIN_DETAIL, cv, KEY_LastName + "=" + Lastname, null);
        db.close();
        return true;
    }

    //private static final String SQL_CREATE_ENTRIES = "Create Table" + DatabaseContract.TableLayout.Table_Name + " (" +
    //        DatabaseContract.TableLayout._ID + " Integer Primary Key," +
    //        DatabaseContract.TableLayout.Column_Name_Title + " Text," +
    //        DatabaseContract.TableLayout.Column_Name_Subtitle + " Text)";

    //private static final String SQL_DELETE_ENTRIES = "Drop Table if exists " + DatabaseContract.TableLayout.Table_Name;

    //public FormAgentDBHelper(Context context)
    //{
    //    super(context, Database_Name, null, Database_Version);
    //}

    //public void onCreate(SQLiteDatabase db)
    //{
    //   db.execSQL(SQL_CREATE_ENTRIES);
    //}

    //public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    //    db.execSQL(SQL_DELETE_ENTRIES);
    //    onCreate(db);
    //}

    //public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion)
    //{
    //    onUpgrade(db, oldVersion, newVersion);
    //}
}
