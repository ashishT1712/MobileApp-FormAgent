package com.example.mirajimlilingwa.formagent;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

public class ViewUsers extends AppCompatActivity {

    FormAgentDBHelper db = FormAgent.db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_users);

        TextView Users = (TextView) findViewById(R.id.ListofUsers);

        List<UserObject> usrList = db.getAllUserList();
        for(UserObject usr : usrList)
        {
            Users.append("ID: " + usr.getId() + "\nFullname: " + usr.getFirst_Name() + " " + usr.getLast_Name() + "\nUsername: " + usr.getUsername()
                    + "\nemail: " + usr.geteMail() + "\n\n");
        }

    }
}
