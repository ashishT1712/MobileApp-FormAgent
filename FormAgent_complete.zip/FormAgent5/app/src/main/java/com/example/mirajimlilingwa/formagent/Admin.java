package com.example.mirajimlilingwa.formagent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class Admin extends AppCompatActivity {

    FormAgentDBHelper db = FormAgent.db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        //Submit button listener
        Button Submit = (Button) findViewById(R.id.SubmitButton);
        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //current variables
                EditText CompanyName = (EditText) findViewById(R.id.CompanyNameText);
                EditText AgentCode = (EditText) findViewById(R.id.AgentCodeText);
                //grap intent extras convert to string
                Bundle bundle = getIntent().getExtras();
                String Lastname = getIntent().getStringExtra("Lastname");

                boolean checkname = Check(Lastname);
                boolean checkCompany = Check(CompanyName.getText().toString());
                boolean checkKey = Check(AgentCode.getText().toString());
                //update current admin with method
                if(checkname == false || checkCompany == false || checkKey == false )
                {

                    Toast.makeText(getApplicationContext(), "Error in Companyname, Agent Code, checkname", Toast.LENGTH_LONG).show();
                }
                else
                {
                    boolean isUpdate = db.UpdateAdminCompany(Lastname, CompanyName.getText().toString(), AgentCode.getText().toString());
                    if( isUpdate == true) {
                        Toast.makeText(getApplicationContext(), "Succesful Registration!", Toast.LENGTH_LONG).show();
                        // Intent intent = new Intent(Admin.this, Succesful.class);
                        //send Agentcode
                        //intent.putExtra("AgentCode", AgentCode.getText().toString());
                        //go to successful page
                        //startActivity(intent);
                        //check database
                        List<AdminObject> admList = db.getAllAdminList();
                        for(AdminObject adm : admList)
                        {
                            String admDetail = "ID: " + adm.getId() + "\nFullname: " + adm.getFirst_Name() + " " + adm.getLast_Name() + "\nUsername: " + adm.getUsername() + "\nPW: " + adm.getPassword()
                                    + "\nemail: " + adm.geteMail() + "\nCompany Name: " + adm.getCompany_Name() + "\nCompany Code: " + adm.getCompany_Key();
                            Log.i("System.in", admDetail);
                        }
                        startActivity(new Intent(getApplicationContext(), FormAgent.class));
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Failed isUpdate", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }

    public boolean Check(String name)
    {
        if(name != "")
            return true;
        else
            return false;
    }

}
