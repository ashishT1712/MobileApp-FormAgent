package com.example.mirajimlilingwa.formagent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.Normalizer;

public class AdminLogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);
        String Name = getIntent().getStringExtra("Name");
        TextView admName = (TextView) findViewById(R.id.AdminName);
        admName.setText(Name);


        //goes to submit forms page
        final Button SubmitForm = (Button) findViewById(R.id.EnterFormsButton);
        SubmitForm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), SubmitForms.class));
            }
        });

        //goes to forms page
        Button formpage = (Button) findViewById(R.id.FormsPageButton);
        formpage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), FormsPage.class));
            }
        });

        //goes to View User Page
        Button userButton = (Button) findViewById(R.id.ViewUsersButton);
        userButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), ViewUsers.class));
            }
        });


    }
}
