package com.example.mirajimlilingwa.formagent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class UserMainPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_main_page);
        String Name = getIntent().getStringExtra("Name");
        TextView uname = (TextView) findViewById(R.id.UserName);
        uname.setText(Name);


        //go to FormsPage
        Button formbutton = (Button) findViewById(R.id.UserFormsPage);
        formbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), FormsPage.class));
            }
        });
    }
}
