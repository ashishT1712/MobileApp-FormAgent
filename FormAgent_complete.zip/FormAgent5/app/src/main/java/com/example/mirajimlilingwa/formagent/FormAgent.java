package com.example.mirajimlilingwa.formagent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

import static com.example.mirajimlilingwa.formagent.R.id.RegisterButton;

public class FormAgent extends AppCompatActivity {

    public static FormAgentDBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_agent);

        db = new FormAgentDBHelper(this);

        Button LoginButton = (Button) findViewById(R.id.LoginButton);
        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText uname = (EditText) findViewById(R.id.Username);
                EditText pw = (EditText) findViewById(R.id.Password);
                String user_name = uname.getText().toString();
                String password = pw.getText().toString();
                List<AdminObject> admList = db.getAllAdminList();
                List<UserObject> userList = db.getAllUserList();
                for(AdminObject adm : admList)
                {
                    //checks if exits in database
                    Log.i("System.in","Username= " + adm.getUsername());
                    Log.i("System.in","PW=" + adm.getPassword());
                    if(user_name.equals(adm.getUsername()) && password.equals(adm.getPassword()))
                    {
                        Toast.makeText(getApplicationContext(), "Successful Admin Login", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(getApplicationContext(), AdminLogin.class);
                        intent.putExtra("Name",adm.getFirst_Name());
                        startActivity(intent);
                    }
                }
                for(UserObject usr : userList)
                {
                    if(user_name.equals(usr.getUsername()) && password.equals(usr.getPassword()))
                    {
                        Toast.makeText(getApplicationContext(), "Succesful User Login", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(getApplicationContext(), UserMainPage.class);
                        intent.putExtra("Name", usr.getFirst_Name());
                        startActivity(intent);
                    }

                }

            }
        });



        Button regButton = (Button) findViewById(R.id.RegisterButton);
        //goes to Register Page
        regButton.setOnClickListener( new View.OnClickListener()//set Listener
        {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(getApplicationContext(), Register.class));
            }//OnClick
        }//View.OnClickListener
        ); //setOnClickListener
    }//OnCreate
}
