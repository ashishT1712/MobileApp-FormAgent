package com.example.mirajimlilingwa.formagent;

/**
 * Created by mstch on 11/20/2017.
 */

public class UserObject {
    int id;
    String Last_Name;
    String First_Name;
    String Username;
    String Password;
    String eMail;

    public UserObject()
    {

    }

    public UserObject(String LastName, String FirstName, String uname, String pw, String email)
    {
        this.Last_Name = LastName;
        this.First_Name = FirstName;
        this.Username = uname;
        this.Password = pw;
        this.eMail = email;
    }
    public String getFirst_Name() {

        return First_Name;
    }

    public void setFirst_Name(String first_Name) {
        First_Name = first_Name;
    }

    public String getLast_Name() {
        return Last_Name;
    }

    public void setLast_Name(String last_Name) {
        Last_Name = last_Name;
    }

    public int getId() {

        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

}
