package com.example.mirajimlilingwa.formagent;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class AdminLogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);
        String Name = getIntent().getStringExtra("Name");
        TextView admName = (TextView) findViewById(R.id.AdminName);
        admName.setText(Name);
    }
}
