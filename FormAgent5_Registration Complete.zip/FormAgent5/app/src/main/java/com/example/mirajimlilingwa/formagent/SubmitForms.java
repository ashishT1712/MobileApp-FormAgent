package com.example.mirajimlilingwa.formagent;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SubmitForms extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submit_forms);
    }

    public static class LoginPage extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_login_page);

        }
    }
}
