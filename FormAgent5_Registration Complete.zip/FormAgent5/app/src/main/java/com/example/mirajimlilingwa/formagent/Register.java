package com.example.mirajimlilingwa.formagent;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import java.util.List;

public class Register extends AppCompatActivity {

    FormAgentDBHelper db = FormAgent.db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //set db
        db = new FormAgentDBHelper(this);

        Button NextButton = (Button) findViewById(R.id.NextButton);

        NextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FormAgentDBHelper DbHelper = new FormAgentDBHelper(getBaseContext());
                //get info
                EditText Fname = (EditText) findViewById(R.id.FirstName);
                EditText Lname = (EditText) findViewById(R.id.LastName);
                EditText PW = (EditText) findViewById(R.id.Password1);
                EditText email = (EditText) findViewById(R.id.email);
                EditText uname = (EditText) findViewById(R.id.UserName);
                //turn into string
                String FirstName = Fname.getText().toString();
                String LastName = Lname.getText().toString();
                String Password = PW.getText().toString();
                String EMAIL = email.getText().toString();
                String Username = uname.getText().toString();
                //radiobox info
                RadioButton AdminB = (RadioButton) findViewById(R.id.AdminBox);
                RadioButton UserB = (RadioButton) findViewById(R.id.UserBox);
                Button submit1 = (Button) findViewById(R.id.NextButton);
                //goes to Admin
                if(AdminB.isChecked() == true)
                {
                    validateEmail valid2 = new validateEmail();
                    boolean val2 = valid2.validate(EMAIL);

                    validation valid = new validation();
                    boolean val = valid.validate(Password);

                    validateUser valid1 = new validateUser();
                    boolean val1= valid1.validate(Username);
                    if(val2 == false || val == false || val1 == false){
                        Log.i("System.in","Email Pattern did not match " + EMAIL);
                        Log.i("System.in","Password Pattern did not match " + Password);
                        Log.i("System.in", "UserName Pattern did not match " + Username);
                    }
                    else {
                        //add to db
                        db.addNewAdmin(new AdminObject(LastName, FirstName, Username, Password, EMAIL));
                        //check db
                        List<AdminObject> admList = db.getAllAdminList();
                        for(AdminObject adm : admList)
                        {
                            String admDetail = "ID: " + adm.getId() + "\nFullname: " + adm.getFirst_Name() + " " + adm.getLast_Name() + "\nUsername: " + adm.getUsername() + "\nPW: " + adm.getPassword()
                                    + "\nemail: " + adm.geteMail() + "\nCompany Name: " + adm.getCompany_Name() + "\nCompany Code: " + adm.getCompany_Key();
                            Log.i("System.in", admDetail);
                        }
                        Intent intent = new Intent(Register.this, Admin.class);
                        getIntent().putExtra("Lastname", LastName);
                        startActivity(intent);
                    }
                }
                //goes to User
                if(UserB.isChecked() == true)
                {
                    validateEmail valid2 = new validateEmail();
                    boolean val2 = valid2.validate(EMAIL);
                    validation valid = new validation();
                    boolean val = valid.validate(Password);
                    validateUser valid1 = new validateUser();
                    boolean val1= valid1.validate(Username);

                    if(val2 == false || val == false || val1 == false){
                        Log.i("System.in","Email Pattern did not match " + EMAIL);
                        Log.i("System.in","Password Pattern did not match " + Password);
                        Log.i("System.in", "UserName Pattern did not match " + Username);
                    }
                    else
                    {
                        db.addNewUser(new UserObject(LastName, FirstName, Username, Password, EMAIL));
                        //check db
                        List<UserObject> userList = db.getAllUserList();
                        for(UserObject user : userList)
                        {
                            String userDetail = "ID: " + user.getId() + "\nFullname: " + user.getFirst_Name() + " " + user.getLast_Name() + "\nUsername: " + user.getUsername() + "\nPW: " + user.getPassword()
                                    + "\nemail: " + user.geteMail();
                            Log.i("System.in", userDetail);
                        }
                        Toast.makeText(getApplicationContext(), "Successfully Registered", Toast.LENGTH_LONG).show();
                        startActivity(new Intent(getApplicationContext(), FormAgent.class));
                    }
                }

            }
        });
    }
}
