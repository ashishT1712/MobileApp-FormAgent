package com.example.mirajimlilingwa.formagent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {

    FormAgentDBHelper db;
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //set db
        db = new FormAgentDBHelper(this);

        Button NextButton = (Button) findViewById(R.id.NextButton);

        NextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FormAgentDBHelper DbHelper = new FormAgentDBHelper(getBaseContext());
                //get info
                EditText Fname = (EditText) findViewById(R.id.FirstName);
                EditText Lname = (EditText) findViewById(R.id.LastName);
                EditText PW = (EditText) findViewById(R.id.Password1);
                EditText email = (EditText) findViewById(R.id.email);
                EditText uname = (EditText) findViewById(R.id.UserName);
                //turn into string
                String FirstName = Fname.getText().toString();
                String LastName = Lname.getText().toString();
                String Password = PW.getText().toString();
                String EMAIL = email.getText().toString();
                String Username = uname.getText().toString();
                //checkbox info
                CheckBox AdminB = (CheckBox) findViewById(R.id.AdminBox);
                //goes to Admin
                if(AdminB.isChecked() == true)
                {
                    //add to db
                    db.addNewAdmin(new AdminObject(LastName, FirstName, Username, EMAIL, Password));
                    startActivity(new Intent(getApplicationContext(), Admin.class));
                }

            }
        });
    }
}
